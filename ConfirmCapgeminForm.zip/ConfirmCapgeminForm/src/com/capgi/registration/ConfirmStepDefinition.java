package com.capgi.registration;

import org.junit.Assert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

import com.capgi.bean.ConfirmPageFactory;

import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;



public class ConfirmStepDefinition {

	private WebDriver driver;
	private ConfirmPageFactory confirmPageFactory;
	
	@Before
	public void setUp() {
		 String path = "C:\\Mandeep\\driverChrome\\chromedriver.exe";
		    System.setProperty("webdriver.chrome.driver",path );
		driver= new ChromeDriver();
	}
	
@Given("^user is on 'Paper Submission' page$")
public void user_is_on_Paper_Submission_page() throws Throwable {
	driver.get("C:\\Mandeep\\BDD_LAB\\ConfirmCapgeminForm\\target\\registration.html");
	confirmPageFactory = new ConfirmPageFactory(driver);
}

@When("^user enters invalid full name$")
public void user_enters_invalid_full_name() throws Throwable {
	confirmPageFactory.setFullName(" ");
	confirmPageFactory.setConfirmButton();

}


@Then("^displays 'Please fill the full Name'$")
public void displays_Please_fill_the_full_Name() throws Throwable {
	//String expectedMessage="Please fill the full Name";
	//String actualMessage=driver.switchTo().alert().getText();
	//Assert.assertEquals(expectedMessage, actualMessage);
	Thread.sleep(2000);
	driver.switchTo().alert().accept();
	driver.close();
}

@When("^user enters invalid email$")
public void user_enters_invalid_email() throws Throwable {
	confirmPageFactory.setFullName("Mandeep");
	confirmPageFactory.setEmail(" ");
	confirmPageFactory.setConfirmButton();
}

@Then("^display 'Please fill the Email'$")
public void display_Please_fill_the_Email() throws Throwable {
	//String expectedMessage="Please fill the Email";
	//String actualMessage=driver.switchTo().alert().getText();
	//Assert.assertEquals(expectedMessage, actualMessage);
	  Thread.sleep(2000);
	driver.switchTo().alert().accept();
	driver.close();
}

@When("^user enters invalid mobile number$")
public void user_enters_invalid_mobile_number() throws Throwable {
	confirmPageFactory.setFullName("Mandeep");
	confirmPageFactory.setEmail("mandeepsingh@gmail.com");
	confirmPageFactory.setMobileNo(" ");
	confirmPageFactory.setConfirmButton();
}

@Then("^display 'Please fill Mobile No\\.'$")
public void display_Please_fill_Mobile_No() throws Throwable {
	//String expectedMessage="'Please fill Mobile No.";
	//String actualMessage=driver.switchTo().alert().getText();
	//Assert.assertEquals(expectedMessage, actualMessage);
	  Thread.sleep(2000);
	driver.switchTo().alert().accept();
	driver.close();
}


@When("^user enters invalid city$")
public void user_enters_invalid_city() throws Throwable {
	confirmPageFactory.setFullName("Mandeep");
	confirmPageFactory.setEmail("mandeepsingh@gmail.com");
	confirmPageFactory.setMobileNo("");
	confirmPageFactory.setConfirmButton();
}

@Then("^display 'Please select city'$")
public void display_Please_select_city() throws Throwable {
	//String expectedMessage="Please select city";
   // String actualMessage=driver.switchTo().alert().getText();
    //Assert.assertEquals(expectedMessage, actualMessage);
    Thread.sleep(2000);
    driver.switchTo().alert().accept();
    driver.close();
}


@When("^user enters valid details$")
public void user_enters_valid_details() throws Throwable {
  
confirmPageFactory.setFullName("Mandeep");
	confirmPageFactory.setEmail("mandeepsingh@gmail.com");
	confirmPageFactory.setMobileNo("9356254786");
	confirmPageFactory.getCity();
	 
	WebElement city=confirmPageFactory.getCity();
      Select se1=new Select(city);
        se1.selectByVisibleText("Bangalore");
	
      WebElement state=confirmPageFactory.getState();
        Select se2=new Select(state);
          se2.selectByVisibleText("Tamilnadu");
          
          confirmPageFactory.setCardHolder("Mandeep"); 
          confirmPageFactory.setDebit("dfsg"); 

          confirmPageFactory.setCvv("1"); 

          confirmPageFactory.setMonth("fsd"); 

          confirmPageFactory.setYear("Analyst"); 

      	
	
}

@Then("^Login succesfully$")
public void login_succesfully() throws Throwable {
	confirmPageFactory.setConfirmButton();
     
}
}
