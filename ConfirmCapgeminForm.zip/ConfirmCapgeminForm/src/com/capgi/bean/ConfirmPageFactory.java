package com.capgi.bean;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;

public class ConfirmPageFactory {
 
	
WebDriver driver;
	
	//step 1 : identify elements
	@FindBy(id="txtFullName")
	@CacheLookup
	WebElement fullName;

	
	@FindBy(how=How.NAME, using="Email")
	@CacheLookup
	WebElement email;
	
	@FindBy(how=How.ID, using="txtPhone")
	@CacheLookup
	WebElement mobileNo;
	
	@FindBy(how=How.NAME, using="city")
	@CacheLookup
	WebElement city;
	
	@FindBy(how=How.NAME, using="state")
	@CacheLookup
	WebElement state;
	
	@FindBy(how=How.ID, using="txtCardholderName")
	@CacheLookup
	WebElement cardHolder;
	
	@FindBy(how=How.ID, using="txtDebit")
	@CacheLookup
	WebElement debit;
	
	@FindBy(how=How.ID, using="txtCvv")
	@CacheLookup
	WebElement cvv;
	
	@FindBy(how=How.ID, using="txtCvv")
	@CacheLookup
	WebElement month;
	
	@FindBy(how=How.ID, using="txtCvv")
	@CacheLookup
	WebElement year;
	
	@FindBy(how=How.ID, using="btnPayment")
	@CacheLookup
	WebElement confirmButton;
	

	



	public ConfirmPageFactory(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	
	public WebDriver getDriver() {
		return driver;
	}


	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}
	

	


	public WebElement getFullName() {
		return fullName;
	}

	
	public void setFullName(String fullName) {
		this.fullName.sendKeys(fullName);
	}


	public WebElement getEmail() {
		return email;
	}


	
	public void setEmail(String email) {
		this.email.sendKeys(email);
	}
	
	public WebElement getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo.sendKeys(mobileNo);
	}
	
	public WebElement getCity() {
		return city;
	}


	public void setCity(String city) {
		this.city.sendKeys(city);
	}

	public WebElement getState() {
		return state;
	}


	public void setState(String state) {
		this.state.sendKeys(state);
	}


	public WebElement getCardHolder() {
		return cardHolder;
	}


	public void setCardHolder(String cardHolder) {
		this.cardHolder.sendKeys(cardHolder);
	}
	
	public WebElement getDebit() {
		return debit;
	}


	public void setDebit(String debit) {
		this.debit.sendKeys(debit);
	}


	public WebElement getCvv() {
		return cvv;
	}


	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}


	public WebElement getMonth() {
		return month;
	}


	public void setMonth(String month) {
		this.month.sendKeys(month);
	}


	public WebElement getYear() {
		return year;
	}


	public void setYear(String year) {
		this.year.sendKeys(year);
	}

	
	public WebElement getConfirmButton() {
		return confirmButton;
	}
	public void setConfirmButton() {
		this.confirmButton.click();
	}
	
	
	
}
